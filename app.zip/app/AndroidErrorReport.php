<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AndroidErrorReport extends Model
{
    protected $table = 'android_errors';
}
